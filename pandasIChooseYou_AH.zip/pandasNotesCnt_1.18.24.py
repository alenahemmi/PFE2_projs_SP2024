"""
notes 1/18/23
"""
import pandas as pd 
# note the link is a relative path, not the whole path
p = pd.read_csv("data/orig/pokemon.csv")

# MERGING
m = pd.read_csv("data/orig/poke_moves.csv")
# use suffixes because there are different id columns with different meanings
# think of the 'on's as the keys linking datasets
pm = p.merge(m, how='left', left_on='id', right_on='pokemon_id', suffixes=('_poke', '_pokemoves'))

# DELETING DATA
# this cleans the data from memory since no longer needed because merge table made
del(m)
del(p)

# LEARN ABOUT MERGED
# notice suffixes at lines 6 (order_poke) and 13 (order_pokemoves)
# print(pm.info())

# print(pm[['identifier', 'move_id']].head(20))

# MERGE ANOTHER
d = pd.read_csv("data/orig/moves.csv")
# print(d.info())
pmd = pm.merge(d, how='left', left_on='move_id', right_on='id', suffixes=('_pm', '_d'))
# print(pmd.info())
# print(pmd[['identifier_pm', 'identifier_d', 'power']].head(20))

# CLEAN DUPLICATES .drop_duplicates()
# DROP NULL VALUES .dropna()
# SORT DATA .sort_values(by=['_'], ascending=Boolean)
# GROUP BY .groupby().agg({field: function to idenftifier for field: join on })
                        # 'identifier_d': lambda x: ', '.join(x),}
                        # inside the grouping, the items that are all in there will be grouped into one line and separated by a comma
# RENAME .rename(columns = ' ': ' ')
    # problem: identifier is index, so doesn't want to change
    # CHANGE INDEX .reset_index()


# print(pmd[['identifier_pm', 'identifier_d', 'power']].head(50).drop_duplicates().dropna().sort_values(by=['power'], ascending = False).head(4).groupby('identifier_pm').agg({'identifier_d': lambda x: ', '.join(x)}).reset_index().rename(columns={'identifier_pm': 'Name', 'identifier_d': 'Attacks'}))

# see how many instances and where region_id is null
l = pd.read_csv('data/orig/locations.csv')
l.isnull().sum().sum()
l.loc[l['region_id'].isnull()]
# fill null values with a value you choose .fillna(' ')
# INPLACE inplace=True is how we write it to the dataset, not just in the displayed copy of the data, but still not anywhere besides memory
l['region_id'].fillna(10, inplace=True)

# when we make all these chaanges to a dataset but want to save the changes, we have to save to our system
# pandas assumes numbers that are strings to be integers (original locations are strings, now locations is ints)
l.to_csv('data/clean/locations.csv', index=False)