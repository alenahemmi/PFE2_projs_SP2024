"""
Alena Hemminger
CSC-103 Programming for everyone SPRING2024
Pandas, I Choose You
"""
import pandas as pd 
import sys

# bring in all csv files from clean folder
encounters = pd.read_csv("data/clean/encounters.csv")
evolutions = pd.read_csv("data/clean/evolutions.csv")
locations = pd.read_csv("data/clean/locations.csv")
moves = pd.read_csv("data/clean/moves.csv")
poke_moves = pd.read_csv("data/clean/poke_moves.csv")
pokemon = pd.read_csv("data/clean/pokemon.csv")
regions = pd.read_csv("data/clean/regions.csv")



# give user choice to exit at any time
# called every time there
def to_exit(input_value):
    if input_value == '%':
        sys.exit()

print("Welcome to your personal Pokédex! This is full of all of the Pokémon since its creation in 1995!")


# create while loop to allow code to run more than once
main_indicator = 1

while main_indicator == 1:
    main_indicator = 0
    print("In your real-life pokedex you can choose to search by one of the following: Pokémon or Region")
    print("Enter '%' to exit at any time")
    
    
    # indicator to signal loop to make sure input is either 1 or 2
    input_indicator = 1
    while input_indicator == 1:    
        
        # create binary choice for how they search
        entry_choice = input("Please indicate 1 for Pokémon or 2 for Region")
        
        # ----------POKEMON SEARCH-----------
        if entry_choice == '1':
            input_indicator = 0
            print("You chose to search by Pokémon name.")
            pokemon_search = input("Please input the name of the Pokémon you would like to learn more about. (To search variations, simply add a hyphen and the variation name.)")
            # find all info from pokemnon.csv on that pokemon

            to_exit(pokemon_search)

            # NAME
            print('Name:', pokemon.identifier[pokemon['identifier']==pokemon_search])

            # INDEX NUMBER
            pokemon_identify = pokemon.id[pokemon["identifier"]==pokemon_search]
            print('ID:', pokemon_identify)

            # LOCATIONS FOUND
            pokemon_to_encounters = encounters.location_area_id[encounters['pokemon_id'].isin(pokemon_identify)]
            encounters_to_locations = locations.identifier[locations['id'].isin(pokemon_to_encounters)]
            print('Locations found:', encounters_to_locations)
            
            # LOWEST LEVEL LOCATION
            # find the level
            lowest_encounter_lvl = min(encounters.min_level[encounters['pokemon_id'].isin(pokemon_identify)])
            # find the location
            lowest_location_id = encounters.location_area_id[encounters['min_level'] == lowest_encounter_lvl]
                 # first_lowest_location is made in case there are multiple locations that have that level for that pokemon
            first_lowest_location = int(lowest_location_id.head(1).iloc[0])
            lowest_location_name = locations.identifier[locations['id'] == first_lowest_location]
            print("Lowest level encounter:", lowest_encounter_lvl, "at", lowest_location_name)

            # HIGHEST LEVEL LOCATION
            # find the level
            highest_encounter_lvl = max(encounters.max_level[encounters['pokemon_id'].isin(pokemon_identify)])
            # find the location
            highest_location_id = encounters.location_area_id[encounters['max_level'] == highest_encounter_lvl]
                # first_highest_location
            first_highest_location = int(highest_location_id.head(1).iloc[0])
            highest_location_name = locations.identifier[locations['id'] == first_highest_location]
            print("Highest level encounter:", highest_encounter_lvl, "at", highest_location_name)

            # STRONGEST MOVES
            # merge the tables needed for moves
            pm = pokemon.merge(poke_moves, how='left', left_on='id', right_on='pokemon_id', suffixes=('_poke', '_pokemoves'))
            pmd = pm.merge(moves, how='left', left_on='move_id', right_on='id', suffixes=('_pm', '_moves'))

            print(
                'Strongest moves (by power):',
                # locate where in the table the pokemon identifier = searched pokemon name and 
                # call the columns identifier_pm (pokemon name), identifier_moves (move name), power 
                # unable to call without 'identifier_pm" printed due to locating by it
                pmd.loc[pmd['identifier_pm'] == pokemon_search, ['identifier_pm', 'identifier_moves', 'power']]
                # drop duplicate moves (ex. pikachu had 4+ different versions of focus punch before dropping)
                .drop_duplicates(subset='identifier_moves')
                # find top 4 strongest moves
                .sort_values(by=['power'], ascending = False).head(4)
                # put the moves into one line separated by commas
                .groupby('identifier_pm').agg({'identifier_moves': lambda x: ', '.join(x)})
                  )







        # ----------REGION SEARCGH----------
        elif entry_choice == '2':
            input_indicator = 0
            print("You chose to search by region.")
            print(regions)
            region_choice = input("Please choose one of the above regions by their id.")

            to_exit(region_choice)

            linkLocation = locations.region_id[locations['region_id'] == int(region_choice)]
            linkEncounters = encounters.pokemon_id[encounters['location_area_id'].isin(linkLocation)]
            findPokemon = pokemon.identifier[pokemon['id'].isin(linkEncounters)]
            print(findPokemon)


            
            
        # loop if input to choose pokemon or region not 1 or 2
        else:
            to_exit(entry_choice)
            input_indicator = 1
            print("Invalid input. Try again.")
            
        
            
            
    # choice to restart or to quit
    print("Your real-life Pokédex has provided all of the information it can. Would you like to start a new search or exit?")
    exit_or_restart = input("Please indicate 1 for new search or % to exit.")
    if exit_or_restart == '1':
        main_indicator = 1
    else:
        to_exit(exit_or_restart)
        print("Invalid input, goodbye.")
        main_indicator = 0
sys.exit()

