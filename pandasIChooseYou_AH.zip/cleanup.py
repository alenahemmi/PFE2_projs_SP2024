"""
Alena Hemminger
CSC-103 Programming for everyone SPRING2024
Pandas, I Choose You

THE PURPOSE OF THIS FILE IS TO CLEAN THE CSV FILES IN THE 
ORIG FOLDER AND TO FILL THE CLEAN FOLDER WITH NEW CLEAN DATA

if no region to location, update w default region 
"Special Event"
"""

import pandas as pd 

encounters = pd.read_csv("data/orig/encounters.csv") 
evolutions = pd.read_csv("data/orig/evolutions.csv") 
locations = pd.read_csv("data/orig/locations.csv")
moves = pd.read_csv("data/orig/moves.csv")
poke_moves = pd.read_csv("data/orig/poke_moves.csv")
pokemon = pd.read_csv("data/orig/pokemon.csv")
regions = pd.read_csv("data/orig/regions.csv")

# check info on locations
print(locations['region_id'].isnull().sum().sum()) # 91 nan
# fill the null region_id with id of 9 to link to the regions table to locations
# region_id of 9 keeps strings and ints separate
locations['region_id'].fillna(9, inplace = True)
# write updated file to clean folder
locations.to_csv('data/clean/locations.csv', index=False)


# create data to add to the regions table 
data = {
    'id': [9],
    'identifier': ['Special Event']
}
# make this data into a dataframe
df = pd.DataFrame(data)
# create new file to append the new data to
regions.to_csv('data/clean/regions.csv', index=False)
# append row to the regions table
df.to_csv('data/clean/regions.csv', mode='a', index=False, header=False)


encounters.to_csv('data/clean/encounters.csv', index=False)
evolutions.to_csv('data/clean/evolutions.csv', index=False)
# locations handled above
moves.to_csv('data/clean/moves.csv', index=False)
poke_moves.to_csv('data/clean/poke_moves.csv', index=False)
pokemon.to_csv('data/clean/pokemon.csv', index=False)
# regions handled above
