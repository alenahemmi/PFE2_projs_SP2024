"""
notes 1/30/24
alena hemminger
csc-103

while and for loops
"""

"""check = False
i = 0

hello="world"

mylist=[]
myotherlist=[1,2,3]

print(len(mylist))
print(myotherlist[2])
print(hello[4])

while check != True:
    i+=1
    print(i)
    if i == 3:
        print("exit")
        break

num = int(input("Favorite number: "))
if num == 1234:
    print('hello world')"""

import pandas as pd

p=pd.read_csv("data/pokemon.csv")

team = []

# \n is new line
# \t is tab
while True:
    n = input("What would you like to do: \n1) Add teammate\n2) Exit\ninput: ")
    if int(n) == 1:
        t=input("Who is your teammate? ")

        # check if input is in pokemon
        # can also use isin
        print(p.loc[p['identifier']==t].empty)
        

        if len(team == 5):
            print('Too many teammates')
            continue
        team.append(t)
        print(team)
        print(len(team))
    if int(n) == 2:
        print('world')
        break