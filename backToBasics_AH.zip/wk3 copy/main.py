"""
Alena Hemminger
CSC103
Goal: Check to see if teammate input is one of the pokemon
      Cut off after 3 teammates input
"""
import pandas as pd

pokemon=pd.read_csv("data/pokemon.csv")

team = []

while True:
    n = input("What would you like to do: \n1) Add teammate\n2) Exit\ninput: ")
    if int(n) == 1:

        teammate=input("Who is your teammate? ")

        if pokemon.loc[pokemon['identifier']==teammate].empty == False: 
            if len(team) == 3:
                print('Too many teammates')
                continue

            team.append(teammate)
        
            print(teammate, "was added to your team.")
            print("New Team:", team)
            
        else:
            print("Invalid input.", teammate, "is not a Pokemon.")

        
    if int(n) == 2:
        print('Exiting...Goodbye')
        break