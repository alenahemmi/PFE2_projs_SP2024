"""
Alena Hemminger
CSC103
create program where user can build a pokemon team and manage it
"""
import pandas as pd

pokemon=pd.read_csv("data/pokemon.csv")

team = []

while True:
    n = input("\nWhat would you like to do: \n\n\t1) Add teammate\n\t2) Manage Team\n\t3) Generate Random Team\n\t4) Exit\n\ninput: ")



    # ADD TEAMMATE
    if int(n) == 1:
        teammate=input("Who is your teammate?\ninput: ")

        # if the desired teammate is not in the list of identifiers (True), they are not a valid pokemon
        if pokemon.loc[pokemon['identifier']==teammate].empty: 
            print("Invalid input.", teammate, "is not a Pokemon.")
            continue

        # if there are already 6 members of the team, cannot add anymore
        elif len(team) == 6:
            print('Too many teammates')
            continue

        # if not 6 and identifier is not empty, add desired teammate
        else:
            team.append(teammate)
            print(teammate, "was added to your team.")
            print("New Team:", team)
            


    # MANAGE TEAM
    if int(n) == 2:
        n= input("What would you like to do: \n\n\t1) Change Order\n\t2) Move single member\n\t3) Delete team member\n\ninput: ")


        # change order
        if int(n) == 1:
            print("Change")
            team.sort(reverse=True)
            print(team)


        # move single member
        if int(n) == 2:
            print(team)
            toMove = input("Who would you like to move?\ninput: ")
            if toMove in team:
                toMoveFrom = team.index(toMove)
                toMoveTo = int(input("What place in the team would you like to move them to?\ninput: "))

                # most users won't know that first position is 0, so make the assumed input to mean one more than actual
                # -1 in if because meant value is 1 more than actual value
                if toMoveFrom == toMoveTo-1:
                    print(toMove, "is already at position", toMoveTo)
                else:
                    team.pop(toMoveFrom)
                    # take input - 1 because most users don't know list locations start at 0
                    team.insert(toMoveTo-1, toMove)
                    print("Team with updated positions:", team)

        # delete team member
        if int(n) == 3:
            print(team)
            toDelete = input("Which teammate would you like to return to the PC (remove from your team)?\ninput: ")
            if toDelete in team:
                toDeleteNum = team.index(toDelete)
                team.pop(toDeleteNum)
                print("\n", toDelete, "removed. Your current team: ", team)
            else:
                print("That pokemon is already not part of your team")
                
        continue



    # GENBERATE RANDOM TEAM
    if int(n) == 3:
        team = pokemon.sample(n=6)['identifier'].tolist()
        print(team)



    # EXIT
    if int(n) == 4:
        print("Your team: ", team)
        print('Exiting...Goodbye')
        break