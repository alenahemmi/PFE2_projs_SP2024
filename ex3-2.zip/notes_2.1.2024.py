"""
notes 1/30/24
alena hemminger
csc-103

while and for loops
"""

"""check = False
i = 0

hello="world"

mylist=[]
myotherlist=[1,2,3]

print(len(mylist))
print(myotherlist[2])
print(hello[4])

while check != True:
    i+=1
    print(i)
    if i == 3:
        print("exit")
        break

num = int(input("Favorite number: "))
if num == 1234:
    print('hello world')"""

import pandas as pd

pokemon=pd.read_csv("data/pokemon.csv")

team = []

""" you can arbitrarily pick numbers for your team: 
    # p.loc[p['id].isin([1,15,500])]
# randomly get pokemon: 
    # p.sample(n=5)
# get only the identifier of random sameple: 
    # p.sample(n=5)['identifier']

# add them to list
    # team = p.sample(n=5)['identifier].tolist()

t = dict(id=1, name='bulbasaur)
t = {'id': 1, 'name': 'bulbasaur'}
list=[dict(id=1, name='bulbasaur'), dict(id=2, name='ivysaur')]
# you cannot sort a list of dictionaries!!!!!

THIS DID NOT WORK
[x in x['name'] for x in t]
"""

g = pd.read_csv("data/poke_by_game.csv")

print(len(g.loc[g['pokemon_id']==3]))

""" while True:
    # \n newline character
    # \t tab character
    n = input("What would you like to do: \n1) Add teammate\n2) Exit\n3) Manage Team\ninput: ")
    if int(n) == 1:

        teammate=input("Who is your teammate? ")
        # could also check with isin function
        if pokemon.loc[pokemon['identifier']==teammate].empty: 
            print("Invalid input.", teammate, "is not a Pokemon.")
            continue
        elif len(team) == 6:
            print('Too many teammates')
            continue
        else:
            team.append(teammate)
        
            print(teammate, "was added to your team.")
            print("New Team:", team)
            
    if int(n) == 3:
        n = input("What would you like to do: \n1) Change Order ")
        if int(n) == 1:
            print("Change")
            # team.sort(reverse=True)

            # this is changing the order of the list
            old=team.index('squirtle')
            # e is whatever pokemon in parenthesis above is
            e = team.pop(old)
            # put in location (#, ) and the thing you're inputting is ( ,_)
            team.insert(2, e)

            print(team)


    if int(n) == 2:
        print('Exiting...Goodbye')
        break
"""