"""
alena hemminger
csc103
dictionary notes
"""

# DICTIONARIES
"""
both of these are valid ways to create dictionaries
thing = dict(id=1, name='tyler')
otherThing = {'id':1, 'name':'tyler'}
"""

import pandas as pd
p=pd.read_csv("data/pokemon.csv")

# find where identifier is bulbasaur and made a disctionary to hold that info
bulba=dict(name=p.loc[p['identifier']=='bulbasaur'].identifier.values[0])

# add that dictionary to the list
team=[bulba]

# add another dictionary in
team.insert(1, dict(name=p.loc[p['identifier']=='squirtle'].identifier.values[0]))

# to add a field in dictionary, update it to put it there or update to change the value of it
team[0].update(id=1)
team[1].update(id=6)

# to remove thing from dictionary, provide key
# team[0].pop('id')

# get dictionary from list, print the value of the key you call
# print(team[1]["name"])

# tells you what the keys are
# print(team[1].keys())

# if only want to work with pokemon that have an id field
"""
for i in team:
    if 'id' in i.keys():
        print('hello ' + i["name"])
"""

# print each value in the dictionaries for name fields
# out = [sub['name'] for sub in team]
# print(out)

# loop through the names and print one at a time
# for i in out:
#     print(i)

# make previous 2 lines in 1
# for i in [sub['name'] for sub in team]:
#     print(i)

# sorted is different from .sort()
import operator
"""
team = sorted(team, key=operator.itemgetter('id'), reverse=True)
print(team)
"""

# records keeps information in clean nice rows (orientation)
rows = p.sample(6)[['id', 'identifier']].to_dict('records')
print(rows)