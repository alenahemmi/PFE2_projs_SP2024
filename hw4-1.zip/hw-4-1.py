

import pandas as pd

p=pd.read_csv("data/pokemon.csv")

team=[]

#p.sample(n=6)["identifier"].tolist()

#p.loc[p['id'].isin([1,15,500])]

#pandas check for specific input being present or not
#p.loc[p['identifier']=='bulbasaur'].empty

#insert item at specific index in list
#team.insert(index,item)

#remove item at specific index
#team.pop(index)


#out=[sub['name'] for sub in team ]
#sorted(team, key=operator.itemgetter('name'))
#dict.update(key=value)
#dict.pop(key)
#p.loc[p['identifier']=='bulbasaur',['id','identifier']]
#p.loc[p['identifier']=='bulbasaur',['id','identifier']].to_dict('records')
#p.loc[p['identifier'].isin(['bulbasaur','squirtle']),['id','identifier']].to_dict('records')


#nickname
# top 3

# CREATE COUNTER TO CHANGE POSITION OF THE INSERTED DICTIONARY IN LIST
count = 0

while True:
   
    
    n=input("What would you like to do:\n\n\t1) Add teammate\n\t2) Exit\n\t3) Manage Team\n\ninput: ")
    if int(n)==1:
        z=input("What would you like to do:\n\n\t1) Add Teammate\n\t2) Generate Random Team\n\t3) Exit\n\ninput: ")
        if int(z)==1:
            t=input("Who is your teamate: ")
            if len(team) == 6:
                print("Too many teammates")
                continue
            elif p.loc[p['identifier']==t].empty:
                print("Invalid Pokemon")
                continue
            # VALIDATE TEAM MEMBER IN POKEMON DATASET
            team.insert(count, dict(id=p.loc[p['identifier']==t].id.values[0], name=p.loc[p['identifier']==t].identifier.values[0]))
            print(team)
            # INCREASE COUNTER TO CHANGE POSITION IN LIST FOR NEXT INSERTED POKEMON
            count += 1

        if int(z)==2:
            # team = p.sample(n=6)['identifier'].tolist()
            team = p.sample(6)[['id', 'identifier']].to_dict('records')
            print(team)


    if int(n)==3:
        # ADD OPTION INDICATOR TO LIST FOR INPUT
        c=input("What would you like to do:\n\n\t1) Change Order\n\t2) Delete Pokemon\n\t3) Add Nickname\n\t4) Remove Nickname\n\ninput: ")
        if int(c)==1:
            move=input("Who would you like to move:")
            if move in team:
                to=input("Where would you like to move them to: ")
                i=team.index(move)
                if i == int(to):
                    print("They're already there!")
                else:
                    team.pop(i)
                    team.insert(int(to),move)
                    print(team)
        if int(c)==2:
            print(team)
            drop=input("Who would you like to remove: ")

            # FIND INDEX OF POKEMON TO DROP
            for i in range(len(team)):
                if team[i]['identifier'] == drop:
                    locInList = i
                    break

            # REMOVE THE DICTIONARY FROM THE LIST
            team.pop(locInList)
            print(team)

        # ADD NICKNAME
        if int(c)==3:
            # GET POKEMON TO NICKNAME
            print(team)
            toNickname = input('Which pokemon would you like to give a nickname? ')

            # FIND THE INDEX OF TONICKNAME POKEMON
            locInList = None
            # USE I TO FIND DICTIONARIES SINCE UNNAMED
            for i in range(len(team)):
                if team[i]['identifier'] == toNickname:
                    locInList = i
                    break

            # GET NICKNAME
            if locInList is not None:
                print('What would you like to nickname', toNickname, '?')
                newNickname = input()

            # NICKNAME THE POKEMON AND ADD IT AS KEY IN DICTIONARY
            # list[locInList]['nickname'] = newNickname
            team[locInList].update(nickname=newNickname)
            print(team)

        # DELETE NICKNAME
        if int(c)==4:
            # ONLY PRINT POKEMON THAT HAVE NICKNAMES
            for i in team:
                if 'nickname' in i.keys():
                    print(i)

            toRemoveNickname = input("Which pokemon would you like to remove the nickname from? ")

            # IF IDENTIFIER IS POKEMON THAT THEY WANT TO REMOVE NICKNAME FROM, PULL INDEX
            for i in range(len(team)):
                if team[i]['identifier'] == toRemoveNickname:
                    locInList = i
                    break

            # REMOVE POKEMON NICKNAME
            team[locInList].pop('nickname')
            print(team)

    if int(n)==2:
        print("Exiting...")
        print(team)
        break
